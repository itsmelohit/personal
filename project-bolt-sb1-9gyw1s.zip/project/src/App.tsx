import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ShoppingCart } from 'lucide-react';
import { ProductCard } from './components/ProductCard';
import { CartDrawer } from './components/CartDrawer';
import { AdminLogin } from './components/AdminLogin';
import { AdminDashboard } from './components/AdminDashboard';
import { UserMenu } from './components/UserMenu';
import { OrderConfirmation } from './components/OrderConfirmation';
import { useCartStore } from './store/cart';
import { useAuthStore } from './store/auth';
import { getProducts } from './lib/db';
import { seedProducts } from './services/seed';
import { Product } from './types';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const user = useAuthStore((state) => state.user);
  
  if (!isAuthenticated || user?.role !== 'admin') {
    return <Navigate to="/admin/login" />;
  }
  
  return <>{children}</>;
}

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const cartItems = useCartStore((state) => state.items);
  const user = useAuthStore((state) => state.user);

  useEffect(() => {
    const initializeProducts = async () => {
      try {
        let productList = await getProducts();
        if (productList.length === 0) {
          await seedProducts();
          productList = await getProducts();
        }
        setProducts(productList);
      } catch (error) {
        console.error('Error loading products:', error);
      }
    };

    initializeProducts();
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            <div className="min-h-screen bg-gray-50">
              <header className="bg-white shadow-sm">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <img 
                        src="/logo.png" 
                        alt="BuyACC.in" 
                        className="h-12"
                      />
                      <h1 className="text-2xl font-bold text-gray-900 ml-4">BuyACC.in</h1>
                    </div>
                    <div className="flex items-center gap-4">
                      <UserMenu />
                      <button
                        onClick={() => setIsCartOpen(true)}
                        className="relative p-2 hover:bg-gray-100 rounded-full"
                      >
                        <ShoppingCart size={24} />
                        {cartItems.length > 0 && (
                          <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                            {cartItems.length}
                          </span>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </header>

              <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {products.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              </main>

              <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
            </div>
          }
        />
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route
          path="/admin/*"
          element={
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />
        <Route path="/payment/confirmation" element={<OrderConfirmation />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;