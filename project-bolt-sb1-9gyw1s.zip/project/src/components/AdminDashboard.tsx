import React, { useState, useEffect } from 'react';
import { LayoutDashboard, Package, Users, TicketIcon, Settings } from 'lucide-react';
import { getUserOrders, getProducts, getUserTickets } from '../lib/db';
import { Order, Product, Ticket } from '../types';
import { formatPrice } from '../lib/utils';

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'products' | 'tickets' | 'settings'>('overview');
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const allOrders = await getUserOrders('all');
      const allProducts = await getProducts();
      const allTickets = await getUserTickets('all');
      setOrders(allOrders);
      setProducts(allProducts);
      setTickets(allTickets);
    };
    fetchData();
  }, []);

  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
  const pendingOrders = orders.filter(order => order.status === 'pending').length;
  const activeTickets = tickets.filter(ticket => ticket.status === 'open').length;

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white h-screen shadow-md">
          <div className="p-6">
            <h2 className="text-xl font-bold">Admin Panel</h2>
          </div>
          <nav className="mt-6">
            <button
              onClick={() => setActiveTab('overview')}
              className={`w-full flex items-center gap-3 px-6 py-3 hover:bg-gray-50 ${
                activeTab === 'overview' ? 'bg-blue-50 text-blue-600' : ''
              }`}
            >
              <LayoutDashboard size={20} />
              Overview
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center gap-3 px-6 py-3 hover:bg-gray-50 ${
                activeTab === 'orders' ? 'bg-blue-50 text-blue-600' : ''
              }`}
            >
              <Package size={20} />
              Orders
            </button>
            <button
              onClick={() => setActiveTab('products')}
              className={`w-full flex items-center gap-3 px-6 py-3 hover:bg-gray-50 ${
                activeTab === 'products' ? 'bg-blue-50 text-blue-600' : ''
              }`}
            >
              <Package size={20} />
              Products
            </button>
            <button
              onClick={() => setActiveTab('tickets')}
              className={`w-full flex items-center gap-3 px-6 py-3 hover:bg-gray-50 ${
                activeTab === 'tickets' ? 'bg-blue-50 text-blue-600' : ''
              }`}
            >
              <TicketIcon size={20} />
              Support Tickets
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`w-full flex items-center gap-3 px-6 py-3 hover:bg-gray-50 ${
                activeTab === 'settings' ? 'bg-blue-50 text-blue-600' : ''
              }`}
            >
              <Settings size={20} />
              Settings
            </button>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Dashboard Overview</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-gray-500 text-sm">Total Revenue</h3>
                  <p className="text-2xl font-bold mt-2">{formatPrice(totalRevenue)}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-gray-500 text-sm">Pending Orders</h3>
                  <p className="text-2xl font-bold mt-2">{pendingOrders}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-gray-500 text-sm">Active Tickets</h3>
                  <p className="text-2xl font-bold mt-2">{activeTickets}</p>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="font-semibold mb-4">Recent Orders</h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3">Order ID</th>
                        <th className="text-left py-3">Customer</th>
                        <th className="text-left py-3">Status</th>
                        <th className="text-right py-3">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.slice(0, 5).map((order) => (
                        <tr key={order.id} className="border-b">
                          <td className="py-3">{order.id}</td>
                          <td className="py-3">{order.userId}</td>
                          <td className="py-3">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              order.status === 'completed' ? 'bg-green-100 text-green-800' :
                              order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {order.status}
                            </span>
                          </td>
                          <td className="py-3 text-right">{formatPrice(order.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Orders</h2>
              <div className="bg-white rounded-lg shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-4">Order ID</th>
                        <th className="text-left p-4">Customer</th>
                        <th className="text-left p-4">Items</th>
                        <th className="text-left p-4">Status</th>
                        <th className="text-left p-4">Payment</th>
                        <th className="text-right p-4">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.map((order) => (
                        <tr key={order.id} className="border-b">
                          <td className="p-4">{order.id}</td>
                          <td className="p-4">{order.userId}</td>
                          <td className="p-4">{order.items.length} items</td>
                          <td className="p-4">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              order.status === 'completed' ? 'bg-green-100 text-green-800' :
                              order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {order.status}
                            </span>
                          </td>
                          <td className="p-4">{order.paymentMethod}</td>
                          <td className="p-4 text-right">{formatPrice(order.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'products' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">Products</h2>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                  Add Product
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product) => (
                  <div key={product.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
                    <img src={product.image} alt={product.name} className="w-full h-48 object-cover" />
                    <div className="p-4">
                      <h3 className="font-semibold">{product.name}</h3>
                      <p className="text-gray-600 text-sm mt-1">{product.description}</p>
                      <div className="mt-4 flex justify-between items-center">
                        <span className="font-bold">{formatPrice(product.price)}</span>
                        <button className="text-blue-600 hover:text-blue-700">Edit</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'tickets' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Support Tickets</h2>
              <div className="bg-white rounded-lg shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-4">Ticket ID</th>
                        <th className="text-left p-4">Subject</th>
                        <th className="text-left p-4">Customer</th>
                        <th className="text-left p-4">Status</th>
                        <th className="text-left p-4">Created</th>
                        <th className="text-left p-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tickets.map((ticket) => (
                        <tr key={ticket.id} className="border-b">
                          <td className="p-4">{ticket.id}</td>
                          <td className="p-4">{ticket.subject}</td>
                          <td className="p-4">{ticket.userId}</td>
                          <td className="p-4">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              ticket.status === 'open' ? 'bg-green-100 text-green-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {ticket.status}
                            </span>
                          </td>
                          <td className="p-4">{new Date(ticket.createdAt).toLocaleDateString()}</td>
                          <td className="p-4">
                            <button className="text-blue-600 hover:text-blue-700">View</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Settings</h2>
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="font-semibold mb-4">Payment Settings</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">PayPal Client ID</label>
                    <input type="text" className="mt-1 block w-full border rounded-md px-3 py-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Coinbase API Key</label>
                    <input type="password" className="mt-1 block w-full border rounded-md px-3 py-2" />
                  </div>
                </div>

                <h3 className="font-semibold mb-4 mt-8">Email Settings</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">SMTP Host</label>
                    <input type="text" className="mt-1 block w-full border rounded-md px-3 py-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">SMTP Port</label>
                    <input type="number" className="mt-1 block w-full border rounded-md px-3 py-2" />
                  </div>
                </div>

                <div className="mt-6">
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    Save Settings
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}