import React, { useState } from 'react';
import { UserLogin } from './UserLogin';
import { UserSignup } from './UserSignup';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');

  if (!isOpen) return null;

  return mode === 'login' ? (
    <UserLogin onClose={onClose} onSwitchToSignup={() => setMode('signup')} />
  ) : (
    <UserSignup onClose={onClose} onSwitchToLogin={() => setMode('login')} />
  );
}