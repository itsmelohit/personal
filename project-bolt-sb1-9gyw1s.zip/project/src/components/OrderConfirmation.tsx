import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { getPaymentStatus } from '../services/nowpayments';
import { formatPrice } from '../lib/utils';
import { Order } from '../types';
import { createOrder } from '../lib/db';
import { useCartStore } from '../store/cart';
import { useAuthStore } from '../store/auth';
import { sendOrderConfirmationEmail } from '../utils/email';

export function OrderConfirmation() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [order, setOrder] = useState<Order | null>(null);
  const clearCart = useCartStore((state) => state.clearCart);
  const user = useAuthStore((state) => state.user);

  useEffect(() => {
    const paymentId = searchParams.get('payment_id');
    const orderId = searchParams.get('order_id');

    if (!paymentId || !user) {
      setStatus('error');
      return;
    }

    const checkPaymentStatus = async () => {
      try {
        const payment = await getPaymentStatus(paymentId);
        
        if (payment.payment_status === 'finished') {
          // Create order record
          const newOrder: Omit<Order, 'id'> = {
            userId: user.id,
            items: payment.metadata.items,
            total: payment.price_amount,
            status: 'completed',
            paymentMethod: 'crypto',
            paymentId,
            createdAt: new Date().toISOString()
          };

          const savedOrder = await createOrder(newOrder);
          setOrder(savedOrder);

          // Send confirmation email
          if (user.email) {
            await sendOrderConfirmationEmail(user.email, {
              orderId: savedOrder.id,
              items: savedOrder.items,
              total: savedOrder.total
            });
          }

          setStatus('success');
          clearCart();
        } else if (['failed', 'expired', 'refunded'].includes(payment.payment_status)) {
          setStatus('error');
        } else {
          // Payment still processing, check again in 5 seconds
          setTimeout(checkPaymentStatus, 5000);
        }
      } catch (error) {
        console.error('Error checking payment status:', error);
        setStatus('error');
      }
    };

    checkPaymentStatus();
  }, [searchParams, user, clearCart]);

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
        {status === 'loading' && (
          <div className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto" />
            <h2 className="text-xl font-semibold mt-4">Processing Payment</h2>
            <p className="text-gray-600 mt-2">
              Please wait while we confirm your payment...
            </p>
          </div>
        )}

        {status === 'success' && order && (
          <div className="text-center">
            <CheckCircle className="h-12 w-12 text-green-600 mx-auto" />
            <h2 className="text-xl font-semibold mt-4">Order Confirmed!</h2>
            <p className="text-gray-600 mt-2">
              Thank you for your purchase. Your order has been confirmed.
            </p>
            
            <div className="mt-6 text-left">
              <h3 className="font-semibold">Order Details</h3>
              <div className="mt-2 space-y-2">
                <p>Order ID: {order.id}</p>
                <p>Date: {new Date(order.createdAt).toLocaleDateString()}</p>
                <div className="border-t border-b py-4 my-4">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex justify-between">
                      <span>{item.name} × {item.quantity}</span>
                      <span>{formatPrice(item.price * item.quantity)}</span>
                    </div>
                  ))}
                </div>
                <div className="flex justify-between font-semibold">
                  <span>Total</span>
                  <span>{formatPrice(order.total)}</span>
                </div>
              </div>
            </div>

            <div className="mt-6">
              <button
                onClick={() => navigate('/')}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 w-full"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        )}

        {status === 'error' && (
          <div className="text-center">
            <XCircle className="h-12 w-12 text-red-600 mx-auto" />
            <h2 className="text-xl font-semibold mt-4">Payment Failed</h2>
            <p className="text-gray-600 mt-2">
              We couldn't process your payment. Please try again.
            </p>
            <div className="mt-6">
              <button
                onClick={() => navigate('/')}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 w-full"
              >
                Return to Shop
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}