import React from 'react';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import { useCartStore } from '../store/cart';
import { useAuthStore } from '../store/auth';
import { formatPrice } from '../lib/utils';
import { createPayment } from '../services/nowpayments';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PaymentModal({ isOpen, onClose }: PaymentModalProps) {
  const items = useCartStore((state) => state.items);
  const clearCart = useCartStore((state) => state.clearCart);
  const user = useAuthStore((state) => state.user);
  const [paymentMethod, setPaymentMethod] = React.useState<'paypal' | 'crypto' | null>(null);
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handlePayPalSuccess = async (details: any) => {
    console.log('PayPal payment successful:', details);
    clearCart();
    onClose();
  };

  const handleCryptoPayment = async () => {
    if (!user) return;
    
    setIsProcessing(true);
    setError(null);

    try {
      const payment = await createPayment({
        items,
        total,
        userId: user.id,
        successUrl: `${window.location.origin}/payment/confirmation`,
        cancelUrl: `${window.location.origin}/cart`,
      });

      if (payment.payment_url) {
        window.location.href = payment.payment_url;
      } else {
        throw new Error('No payment URL received');
      }
    } catch (error) {
      console.error('Error creating crypto payment:', error);
      setError('Failed to initiate cryptocurrency payment. Please try again.');
      setIsProcessing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-md w-96 max-w-full">
        <h2 className="text-2xl font-bold mb-6">Choose Payment Method</h2>
        
        {error && (
          <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">
            {error}
          </div>
        )}

        <div className="space-y-4">
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">Order Summary</h3>
            {items.map((item) => (
              <div key={item.id} className="flex justify-between text-sm">
                <span>{item.name} × {item.quantity}</span>
                <span>{formatPrice(item.price * item.quantity)}</span>
              </div>
            ))}
            <div className="mt-2 pt-2 border-t flex justify-between font-bold">
              <span>Total:</span>
              <span>{formatPrice(total)}</span>
            </div>
          </div>

          <div className="space-y-2">
            <button
              onClick={() => setPaymentMethod('paypal')}
              className="w-full p-4 border rounded-lg hover:bg-gray-50 flex items-center justify-center gap-2"
              disabled={isProcessing}
            >
              <img src="https://www.paypalobjects.com/webstatic/mktg/logo/pp_cc_mark_37x23.jpg" 
                   alt="PayPal" 
                   className="h-6" />
              Pay with PayPal
            </button>

            <button
              onClick={() => setPaymentMethod('crypto')}
              className="w-full p-4 border rounded-lg hover:bg-gray-50 flex items-center justify-center gap-2"
              disabled={isProcessing}
            >
              <img src="https://nowpayments.io/images/favicon.png" 
                   alt="NOWPayments" 
                   className="h-6" />
              Pay with Crypto
            </button>
          </div>

          {paymentMethod === 'paypal' && (
            <div className="mt-4">
              <PayPalScriptProvider options={{ 
                "client-id": import.meta.env.VITE_PAYPAL_CLIENT_ID || '',
                currency: "USD"
              }}>
                <PayPalButtons
                  createOrder={(data, actions) => {
                    return actions.order.create({
                      purchase_units: [{
                        amount: {
                          value: total.toString()
                        }
                      }]
                    });
                  }}
                  onApprove={async (data, actions) => {
                    const details = await actions.order?.capture();
                    if (details) {
                      await handlePayPalSuccess(details);
                    }
                  }}
                />
              </PayPalScriptProvider>
            </div>
          )}

          {paymentMethod === 'crypto' && (
            <div className="mt-4">
              <button
                onClick={handleCryptoPayment}
                disabled={isProcessing}
                className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {isProcessing ? 'Processing...' : 'Proceed to Crypto Checkout'}
              </button>
            </div>
          )}

          <button
            onClick={onClose}
            className="w-full mt-4 py-2 text-gray-600 hover:text-gray-900"
            disabled={isProcessing}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}