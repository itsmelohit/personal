import React, { useState } from 'react';
import { User, LogOut } from 'lucide-react';
import { useAuthStore } from '../store/auth';
import { AuthModal } from './AuthModal';

export function UserMenu() {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const { user, logout } = useAuthStore();

  if (user?.role === 'admin') return null;

  return (
    <>
      {user ? (
        <div className="flex items-center gap-4">
          <span className="text-gray-700">
            <User className="inline-block mr-2" size={20} />
            {user.name}
          </span>
          <button
            onClick={logout}
            className="text-gray-600 hover:text-gray-900 flex items-center gap-1"
          >
            <LogOut size={20} />
            Logout
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-4">
          <button
            onClick={() => setShowAuthModal(true)}
            className="text-gray-600 hover:text-gray-900"
          >
            Login
          </button>
          <button
            onClick={() => {
              setShowAuthModal(true);
            }}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            Sign Up
          </button>
        </div>
      )}

      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </>
  );
}