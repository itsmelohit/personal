import nodemailer from 'nodemailer';

export const emailConfig = {
  host: import.meta.env.VITE_SMTP_HOST,
  port: parseInt(import.meta.env.VITE_SMTP_PORT),
  secure: true,
  auth: {
    user: import.meta.env.VITE_SMTP_USER,
    pass: import.meta.env.VITE_SMTP_PASS
  }
};

export const transporter = nodemailer.createTransport(emailConfig);