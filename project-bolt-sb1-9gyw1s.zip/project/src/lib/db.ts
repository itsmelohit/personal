import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { createId } from '@paralleldrive/cuid2';
import { Product, User, Order, Ticket, TicketMessage } from '../types';

interface ShopDB extends DBSchema {
  products: {
    key: string;
    value: Product;
    indexes: { 'by-category': string };
  };
  users: {
    key: string;
    value: User;
    indexes: { 'by-email': string };
  };
  orders: {
    key: string;
    value: Order;
    indexes: { 'by-user': string };
  };
  tickets: {
    key: string;
    value: Ticket;
    indexes: { 'by-user': string };
  };
  ticketMessages: {
    key: string;
    value: TicketMessage;
    indexes: { 'by-ticket': string };
  };
}

let db: IDBPDatabase<ShopDB>;

export async function initDB() {
  db = await openDB<ShopDB>('digital-goods-shop', 1, {
    upgrade(db) {
      // Products store
      const productStore = db.createObjectStore('products', { keyPath: 'id' });
      productStore.createIndex('by-category', 'category');

      // Users store
      const userStore = db.createObjectStore('users', { keyPath: 'id' });
      userStore.createIndex('by-email', 'email', { unique: true });

      // Orders store
      const orderStore = db.createObjectStore('orders', { keyPath: 'id' });
      orderStore.createIndex('by-user', 'userId');

      // Support tickets store
      const ticketStore = db.createObjectStore('tickets', { keyPath: 'id' });
      ticketStore.createIndex('by-user', 'userId');

      // Ticket messages store
      const messageStore = db.createObjectStore('ticketMessages', { keyPath: 'id' });
      messageStore.createIndex('by-ticket', 'ticketId');
    },
  });
}

// Products
export async function getProducts(): Promise<Product[]> {
  await initDB();
  return db.getAll('products');
}

export async function getProductsByCategory(category: string): Promise<Product[]> {
  await initDB();
  return db.getAllFromIndex('products', 'by-category', category);
}

export async function addProduct(product: Omit<Product, 'id'>): Promise<Product> {
  await initDB();
  const id = createId();
  const newProduct = { ...product, id };
  await db.add('products', newProduct);
  return newProduct;
}

// Users
export async function getUserByEmail(email: string): Promise<User | undefined> {
  await initDB();
  return db.getFromIndex('users', 'by-email', email);
}

export async function createUser(user: Omit<User, 'id'>): Promise<User> {
  await initDB();
  const id = createId();
  const newUser = { ...user, id };
  await db.add('users', newUser);
  return newUser;
}

// Orders
export async function createOrder(order: Omit<Order, 'id'>): Promise<Order> {
  await initDB();
  const id = createId();
  const newOrder = { ...order, id };
  await db.add('orders', newOrder);
  return newOrder;
}

export async function getUserOrders(userId: string): Promise<Order[]> {
  await initDB();
  return db.getAllFromIndex('orders', 'by-user', userId);
}

// Support Tickets
export async function createTicket(ticket: Omit<Ticket, 'id'>): Promise<Ticket> {
  await initDB();
  const id = createId();
  const newTicket = { ...ticket, id };
  await db.add('tickets', newTicket);
  return newTicket;
}

export async function getUserTickets(userId: string): Promise<Ticket[]> {
  await initDB();
  return db.getAllFromIndex('tickets', 'by-user', userId);
}

export async function addTicketMessage(message: Omit<TicketMessage, 'id'>): Promise<TicketMessage> {
  await initDB();
  const id = createId();
  const newMessage = { ...message, id };
  await db.add('ticketMessages', newMessage);
  return newMessage;
}

export async function getTicketMessages(ticketId: string): Promise<TicketMessage[]> {
  await initDB();
  return db.getAllFromIndex('ticketMessages', 'by-ticket', ticketId);
}