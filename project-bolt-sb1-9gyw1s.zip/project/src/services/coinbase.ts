import { CartItem } from '../types';

const COINBASE_API_URL = 'https://api.commerce.coinbase.com';
const API_KEY = '29957c0c-4406-4489-aed6-a44de619bf1b';

export interface CreateChargeParams {
  items: CartItem[];
  total: number;
  userId: string;
  successUrl: string;
  cancelUrl: string;
}

export async function createCharge({
  items,
  total,
  userId,
  successUrl,
  cancelUrl,
}: CreateChargeParams) {
  try {
    const response = await fetch(`${COINBASE_API_URL}/charges`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CC-Api-Key': API_KEY,
        'X-CC-Version': '2018-03-22',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        name: 'Digital Goods Purchase',
        description: `Purchase of ${items.length} digital items`,
        pricing_type: 'fixed_price',
        local_price: {
          amount: total.toString(),
          currency: 'USD',
        },
        metadata: {
          userId,
          items: items.map(item => ({
            id: item.id,
            name: item.name,
            quantity: item.quantity,
          })),
        },
        redirect_url: successUrl,
        cancel_url: cancelUrl,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('Coinbase API error:', errorData);
      throw new Error(errorData.message || 'Failed to create Coinbase charge');
    }

    const data = await response.json();
    return data.data;
  } catch (error) {
    console.error('Error creating Coinbase charge:', error);
    throw error;
  }
}

export async function getCharge(chargeId: string) {
  try {
    const response = await fetch(`${COINBASE_API_URL}/charges/${chargeId}`, {
      headers: {
        'X-CC-Api-Key': API_KEY,
        'X-CC-Version': '2018-03-22',
        'Accept': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch charge');
    }

    const data = await response.json();
    return data.data;
  } catch (error) {
    console.error('Error fetching charge:', error);
    throw error;
  }
}