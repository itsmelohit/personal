// Mock email service for development
class MockEmailService {
  private static instance: MockEmailService;
  private emails: Array<{
    to: string;
    subject: string;
    html: string;
    sentAt: Date;
  }> = [];

  private constructor() {}

  static getInstance(): MockEmailService {
    if (!MockEmailService.instance) {
      MockEmailService.instance = new MockEmailService();
    }
    return MockEmailService.instance;
  }

  async sendMail(options: { to: string; subject: string; html: string }) {
    console.log('📧 Mock email sent:', {
      to: options.to,
      subject: options.subject,
      sentAt: new Date().toISOString()
    });
    
    this.emails.push({
      ...options,
      sentAt: new Date()
    });

    return true;
  }

  getEmails() {
    return this.emails;
  }

  clearEmails() {
    this.emails = [];
  }
}

export const emailService = MockEmailService.getInstance();