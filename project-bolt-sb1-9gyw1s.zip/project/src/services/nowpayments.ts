import { CartItem } from '../types';

const API_KEY = import.meta.env.VITE_NOWPAYMENTS_API_KEY;
const PUBLIC_KEY = import.meta.env.VITE_NOWPAYMENTS_PUBLIC_KEY;

interface CreatePaymentParams {
  items: CartItem[];
  total: number;
  userId: string;
  successUrl: string;
  cancelUrl: string;
}

export async function createPayment({
  items,
  total,
  userId,
  successUrl,
  cancelUrl,
}: CreatePaymentParams) {
  try {
    const response = await fetch('https://api.nowpayments.io/v1/payment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
      },
      body: JSON.stringify({
        price_amount: total,
        price_currency: 'usd',
        order_id: `order_${Date.now()}`,
        order_description: `Purchase of ${items.length} digital items`,
        success_url: successUrl,
        cancel_url: cancelUrl,
        is_fixed_rate: true,
        public_key: PUBLIC_KEY,
        ipn_callback_url: import.meta.env.VITE_NOWPAYMENTS_IPN_URL,
        metadata: {
          userId,
          items: items.map(item => ({
            id: item.id,
            name: item.name,
            quantity: item.quantity,
          })),
        },
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to create payment');
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating NOWPayments payment:', error);
    throw error;
  }
}

export async function getPaymentStatus(paymentId: string) {
  try {
    const response = await fetch(`https://api.nowpayments.io/v1/payment/${paymentId}`, {
      headers: {
        'x-api-key': API_KEY,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch payment status');
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching payment status:', error);
    throw error;
  }
}