import { addProduct } from '../lib/db';

export async function seedProducts() {
  const products = [
    {
      name: 'Premium WordPress Theme',
      description: 'A beautiful and responsive WordPress theme for your website',
      price: 59,
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800',
      category: 'themes',
      downloadUrl: '/downloads/premium-wp-theme.zip'
    },
    {
      name: 'UI Kit Bundle',
      description: 'Complete UI kit with over 1000+ components',
      price: 79,
      image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&q=80&w=800',
      category: 'ui-kits',
      downloadUrl: '/downloads/ui-kit-bundle.zip'
    },
    {
      name: 'Icon Pack Pro',
      description: '5000+ premium icons in multiple formats',
      price: 39,
      image: 'https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?auto=format&fit=crop&q=80&w=800',
      category: 'icons',
      downloadUrl: '/downloads/icon-pack-pro.zip'
    }
  ];

  for (const product of products) {
    await addProduct(product);
  }
}