import { create } from 'zustand';
import { User } from '../types';
import { getSession, clearSession } from '../utils/auth';

interface AuthStore {
  user: User | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: getSession(),
  isAuthenticated: !!getSession(),
  login: (user) => set({ user, isAuthenticated: true }),
  logout: () => {
    clearSession();
    set({ user: null, isAuthenticated: false });
  },
}));