import { User } from '../types';
import { sendConfirmationEmail } from './email';
import { emailService } from '../services/mockEmail';
import bcrypt from 'bcryptjs';
import { signJWT, verifyJWT } from './jwt';

export const ADMIN_CREDENTIALS = {
  username: 'Lohit',
  password: 'F9YeYzZZ$$$',
  email: 'ebuttowski@gmail.com'
};

// In-memory storage (in production, use a database)
const pendingConfirmations = new Map<string, { email: string; hash: string }>();
let currentOTP: string | null = null;
let otpExpiry: Date | null = null;

export async function validateCredentials(username: string, password: string): Promise<boolean> {
  return username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password;
}

export async function generateOTP(): Promise<void> {
  // Generate a 6-digit OTP
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  currentOTP = otp;
  otpExpiry = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes expiry

  try {
    await emailService.sendMail({
      to: ADMIN_CREDENTIALS.email,
      subject: 'Admin Login OTP',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>Admin Login OTP</h2>
          <p>Your OTP for admin login is: <strong>${otp}</strong></p>
          <p>This OTP will expire in 5 minutes.</p>
          <p>If you didn't request this OTP, please ignore this email.</p>
        </div>
      `
    });
    console.log('OTP for testing:', otp); // Remove in production
  } catch (error) {
    console.error('Error sending OTP:', error);
    throw new Error('Failed to send OTP');
  }
}

export async function verifyOTP(otp: string): Promise<boolean> {
  if (!currentOTP || !otpExpiry) return false;
  if (Date.now() > otpExpiry.getTime()) return false;
  return otp === currentOTP;
}

export function clearOTP(): void {
  currentOTP = null;
  otpExpiry = null;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function comparePasswords(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function generateEmailToken(email: string): Promise<string> {
  return signJWT({ email });
}

export async function verifyEmailToken(token: string): Promise<string | null> {
  const payload = await verifyJWT<{ email: string }>(token);
  return payload?.email ?? null;
}

export async function initiateEmailConfirmation(email: string, passwordHash: string): Promise<boolean> {
  try {
    const token = await generateEmailToken(email);
    pendingConfirmations.set(token, { email, hash: passwordHash });
    await sendConfirmationEmail(email, token);
    return true;
  } catch (error) {
    console.error('Error initiating email confirmation:', error);
    return false;
  }
}

export async function confirmEmail(token: string): Promise<User | null> {
  const email = await verifyEmailToken(token);
  if (!email) return null;

  const pendingUser = pendingConfirmations.get(token);
  if (!pendingUser || pendingUser.email !== email) return null;

  // In production, save the user to a database
  const user: User = {
    id: Math.random().toString(36).substr(2, 9),
    email,
    name: email.split('@')[0],
    role: 'user'
  };

  pendingConfirmations.delete(token);
  return user;
}

// Session management
export function setSession(user: User): void {
  sessionStorage.setItem('user', JSON.stringify(user));
}

export function getSession(): User | null {
  const userStr = sessionStorage.getItem('user');
  return userStr ? JSON.parse(userStr) : null;
}

export function clearSession(): void {
  sessionStorage.removeItem('user');
}