import { emailService } from '../services/mockEmail';

export async function sendConfirmationEmail(to: string, token: string) {
  const confirmationLink = `http://localhost:5173/confirm-email?token=${token}`;

  try {
    await emailService.sendMail({
      to,
      subject: 'Confirm Your Email',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>Welcome to Digital Goods Shop!</h2>
          <p>Thank you for signing up. Please confirm your email address by clicking the link below:</p>
          <p>
            <a href="${confirmationLink}" style="display: inline-block; padding: 12px 24px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 6px;">
              Confirm Email
            </a>
          </p>
          <p>If you didn't create an account, you can safely ignore this email.</p>
          <p>Best regards,<br>Digital Goods Shop Team</p>
        </div>
      `
    });
    return true;
  } catch (error) {
    console.error('Error sending confirmation email:', error);
    return false;
  }
}

export async function sendPasswordResetEmail(to: string, token: string) {
  const resetLink = `http://localhost:5173/reset-password?token=${token}`;

  try {
    await emailService.sendMail({
      to,
      subject: 'Reset Your Password',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>Password Reset Request</h2>
          <p>You requested to reset your password. Click the link below to set a new password:</p>
          <p>
            <a href="${resetLink}" style="display: inline-block; padding: 12px 24px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 6px;">
              Reset Password
            </a>
          </p>
          <p>If you didn't request a password reset, you can safely ignore this email.</p>
          <p>Best regards,<br>Digital Goods Shop Team</p>
        </div>
      `
    });
    return true;
  } catch (error) {
    console.error('Error sending password reset email:', error);
    return false;
  }
}

export async function sendOrderConfirmationEmail(to: string, orderDetails: {
  orderId: string;
  items: Array<{ name: string; quantity: number; price: number }>;
  total: number;
}) {
  try {
    await emailService.sendMail({
      to,
      subject: 'Order Confirmation',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>Thank You for Your Order!</h2>
          <p>Your order (ID: ${orderDetails.orderId}) has been confirmed.</p>
          
          <h3>Order Summary:</h3>
          <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
            <thead>
              <tr style="background-color: #f3f4f6;">
                <th style="padding: 12px; text-align: left; border: 1px solid #e5e7eb;">Item</th>
                <th style="padding: 12px; text-align: right; border: 1px solid #e5e7eb;">Quantity</th>
                <th style="padding: 12px; text-align: right; border: 1px solid #e5e7eb;">Price</th>
              </tr>
            </thead>
            <tbody>
              ${orderDetails.items.map(item => `
                <tr>
                  <td style="padding: 12px; border: 1px solid #e5e7eb;">${item.name}</td>
                  <td style="padding: 12px; text-align: right; border: 1px solid #e5e7eb;">${item.quantity}</td>
                  <td style="padding: 12px; text-align: right; border: 1px solid #e5e7eb;">$${item.price.toFixed(2)}</td>
                </tr>
              `).join('')}
              <tr style="background-color: #f3f4f6;">
                <td colspan="2" style="padding: 12px; text-align: right; border: 1px solid #e5e7eb;"><strong>Total:</strong></td>
                <td style="padding: 12px; text-align: right; border: 1px solid #e5e7eb;"><strong>$${orderDetails.total.toFixed(2)}</strong></td>
              </tr>
            </tbody>
          </table>

          <p>You will receive your digital goods download links shortly in a separate email.</p>
          <p>Best regards,<br>Digital Goods Shop Team</p>
        </div>
      `
    });
    return true;
  } catch (error) {
    console.error('Error sending order confirmation email:', error);
    return false;
  }
}