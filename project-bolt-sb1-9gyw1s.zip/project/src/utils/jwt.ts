import * as jose from 'jose';

const secret = new TextEncoder().encode('your-secret-key'); // In production, use environment variables

export async function signJWT(payload: object, expiresIn: string = '1h'): Promise<string> {
  const jwt = await new jose.SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setExpirationTime(expiresIn)
    .setIssuedAt()
    .sign(secret);
  return jwt;
}

export async function verifyJWT<T>(token: string): Promise<T | null> {
  try {
    const { payload } = await jose.jwtVerify(token, secret);
    return payload as T;
  } catch {
    return null;
  }
}